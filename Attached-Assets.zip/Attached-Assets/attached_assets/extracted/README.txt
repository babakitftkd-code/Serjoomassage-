
SERJOOMASSAGE – Wix Version 1 Booking Setup

Because Wix does not allow importing a full site via ZIP,
this package contains the exact files you paste into Wix Velo.

Steps

1) Go to https://wix.com
2) Create a new site
3) Turn on DEV MODE (Velo)

4) Create a database:
Content Manager → New Collection

Name:
Bookings

Fields:
name (text)
phone (text)
service (text)
date (datetime)
createdAt (datetime)

5) Design page elements in Wix editor:

Input field → ID: nameInput
Input field → ID: phoneInput
Dropdown → ID: serviceDropdown
Date Picker → ID: datePicker
Button → ID: bookButton
Text → ID: successText

6) Open PAGE CODE and paste the code from:
pageCode.js

7) Publish site.

Now your booking system works.
