
import wixData from 'wix-data';

$w.onReady(function () {

    $w("#successText").hide();

    $w("#serviceDropdown").options = [
        { label: "Relaxation Massage", value: "Relaxation Massage" },
        { label: "Deep Tissue Massage", value: "Deep Tissue Massage" },
        { label: "Back Pain Therapy", value: "Back Pain Therapy" }
    ];

    $w("#bookButton").onClick(async () => {

        const name = $w("#nameInput").value;
        const phone = $w("#phoneInput").value;
        const service = $w("#serviceDropdown").value;
        const date = $w("#datePicker").value;

        if(!name || !phone || !date){
            console.log("Missing fields");
            return;
        }

        const booking = {
            name: name,
            phone: phone,
            service: service,
            date: date,
            createdAt: new Date()
        };

        try {

            await wixData.insert("Bookings", booking);

            $w("#successText").text = "Appointment booked successfully!";
            $w("#successText").show();

            $w("#nameInput").value = "";
            $w("#phoneInput").value = "";

        } catch(err){
            console.error(err);
        }

    });

});
