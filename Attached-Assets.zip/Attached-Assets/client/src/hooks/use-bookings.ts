import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type BookingInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useCreateBooking() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: BookingInput) => {
      // Coerce the date before validation just in case
      const payload = { ...data, date: new Date(data.date) };
      const validated = api.bookings.create.input.parse(payload);
      
      const res = await fetch(api.bookings.create.path, {
        method: api.bookings.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        let errorMessage = "Failed to book appointment";
        try {
          const errorData = api.bookings.create.responses[400].parse(await res.json());
          errorMessage = errorData.message;
        } catch (e) {
          // If not our specific 400 validation error, keep default message
        }
        throw new Error(errorMessage);
      }
      
      return api.bookings.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.list.path] });
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
