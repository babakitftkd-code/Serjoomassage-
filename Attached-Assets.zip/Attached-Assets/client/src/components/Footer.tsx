import { Leaf } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-secondary/30 pt-16 pb-8 border-t border-border mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12 text-center md:text-left">
          <div className="flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 mb-4">
              <Leaf className="w-5 h-5 text-primary" />
              <span className="font-display font-semibold text-xl text-primary">SerjooMassage</span>
            </div>
            <p className="text-muted-foreground text-sm max-w-xs leading-relaxed">
              Experience profound relaxation and healing. We bring balance to your body and tranquility to your mind.
            </p>
          </div>
          
          <div className="flex flex-col items-center md:items-start">
            <h3 className="font-display font-semibold text-lg mb-4">Hours</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Monday - Friday: 9am - 8pm</li>
              <li>Saturday: 10am - 6pm</li>
              <li>Sunday: Closed</li>
            </ul>
          </div>
          
          <div className="flex flex-col items-center md:items-start">
            <h3 className="font-display font-semibold text-lg mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>123 Wellness Avenue</li>
              <li>Suite 200</li>
              <li>+1 (555) 123-4567</li>
              <li>hello@serjoomassage.com</li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-border/50 text-center text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} SerjooMassage. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
