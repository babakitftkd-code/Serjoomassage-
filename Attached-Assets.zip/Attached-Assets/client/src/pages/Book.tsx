import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { FadeIn } from "@/components/FadeIn";
import { useCreateBooking } from "@/hooks/use-bookings";
import { insertBookingSchema } from "@shared/schema";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { CalendarIcon, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";

export default function Book() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const initialService = searchParams.get("service") || "";

  const [isSuccess, setIsSuccess] = useState(false);
  const { mutate: createBooking, isPending } = useCreateBooking();

  const form = useForm<z.infer<typeof insertBookingSchema>>({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      name: "",
      phone: "",
      service: initialService,
      date: new Date(),
    },
  });

  const onSubmit = (values: z.infer<typeof insertBookingSchema>) => {
    createBooking(values, {
      onSuccess: () => {
        setIsSuccess(true);
        form.reset({
          name: "",
          phone: "",
          service: "",
          date: new Date(),
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    });
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-background py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
        <FadeIn className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-medium mb-4">Book Your Appointment</h1>
          <p className="text-muted-foreground text-lg">
            Reserve your time for relaxation and healing.
          </p>
        </FadeIn>

        {isSuccess ? (
          <FadeIn>
            <div className="bg-white rounded-3xl p-12 text-center shadow-lg border border-border/50 flex flex-col items-center">
              <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </div>
              <h2 className="text-3xl font-display font-medium mb-4">Appointment booked successfully!</h2>
              <p className="text-muted-foreground mb-8 text-lg max-w-md mx-auto">
                Thank you for choosing SerjooMassage. We have received your booking and look forward to seeing you.
              </p>
              <Button 
                onClick={() => setIsSuccess(false)}
                variant="outline"
                className="rounded-full px-8"
              >
                Book Another Appointment
              </Button>
            </div>
          </FadeIn>
        ) : (
          <FadeIn delay={0.2}>
            <div className="bg-card rounded-3xl p-8 md:p-12 shadow-xl shadow-black/5 border border-border/50">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium">Full Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Jane Doe" 
                              className="h-12 rounded-xl bg-background/50 border-border focus:border-primary focus:ring-primary/20 transition-all" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium">Phone Number</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="(555) 123-4567" 
                              className="h-12 rounded-xl bg-background/50 border-border focus:border-primary focus:ring-primary/20 transition-all" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="service"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-medium">Treatment Service</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-12 rounded-xl bg-background/50 border-border focus:ring-primary/20 transition-all">
                              <SelectValue placeholder="Select a massage service" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="rounded-xl border-border/50 shadow-lg">
                            <SelectItem value="Relaxation Massage" className="py-3">Relaxation Massage - 60 min</SelectItem>
                            <SelectItem value="Deep Tissue Massage" className="py-3">Deep Tissue Massage - 60 min</SelectItem>
                            <SelectItem value="Back Pain Therapy" className="py-3">Back Pain Therapy - 75 min</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel className="text-base font-medium">Date & Time</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full h-12 rounded-xl bg-background/50 border-border hover:bg-background justify-start text-left font-normal transition-all",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                <CalendarIcon className="mr-3 h-5 w-5 opacity-50" />
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 rounded-xl border-border/50 shadow-xl" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) =>
                                date < new Date() || date < new Date("1900-01-01")
                              }
                              initialFocus
                              className="p-3"
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    disabled={isPending}
                    className="w-full h-14 text-lg rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300"
                  >
                    {isPending ? "Booking..." : "Book Appointment"}
                  </Button>
                </form>
              </Form>
            </div>
          </FadeIn>
        )}
      </div>
    </div>
  );
}
