import ServicesSection from "../components/ServicesSection"
import FloatingContactBar from "../components/FloatingContactBar"
import SocialLinks from "../components/SocialLinks"
import { Link } from "wouter";
import { FadeIn } from "@/components/FadeIn";
import { Button } from "@/components/ui/button";
import { Sparkles, HeartPulse, Flower2 } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative h-[85vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        {/* landing page hero spa massage relaxing earth tones */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?w=1920&h=1080&fit=crop&q=80"
            alt="Relaxing spa setting"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-background/80 backdrop-blur-[2px]"></div>
        </div>

        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <FadeIn>
            <span className="text-primary font-medium tracking-widest uppercase text-sm mb-6 block">
              serjoomassage
            </span>
          </FadeIn>
          <FadeIn delay={0.2}>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-medium text-foreground mb-8 max-w-4xl mx-auto leading-tight">
              profeshnal massage in toronto
            </h1>
          </FadeIn>
          <FadeIn delay={0.4}>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto font-light">
              Experience the healing power of therapeutic touch. Melt away stress, relieve pain, and rediscover your natural state of well-being.
            </p>
          </FadeIn>
          <FadeIn delay={0.6}>
            <Link href="/book">
              <Button size="lg" className="rounded-full px-8 py-6 text-lg bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300">
                Book Your Escape
              </Button>
            </Link>
          </FadeIn>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <FadeIn>
              <h2 className="text-3xl md:text-4xl font-display font-medium mb-4">Why Choose SerjooMassage</h2>
              <div className="h-1 w-20 bg-primary/30 mx-auto rounded-full"></div>
            </FadeIn>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: <Flower2 className="w-8 h-8 text-primary" />,
                title: "Tranquil Environment",
                desc: "Step into a space designed specifically to calm the nervous system and quiet the mind."
              },
              {
                icon: <HeartPulse className="w-8 h-8 text-primary" />,
                title: "Expert Therapists",
                desc: "Our certified professionals tailor each session to address your unique physical needs."
              },
              {
                icon: <Sparkles className="w-8 h-8 text-primary" />,
                title: "Premium Products",
                desc: "We use only organic, skin-nourishing oils and lotions to enhance your healing experience."
              }
            ].map((feature, i) => (
              <FadeIn key={i} delay={i * 0.2} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/50 mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-display font-medium mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-secondary/30 relative">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-display font-medium mb-6">Ready to unwind?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-10 text-lg">
              Your journey to relaxation is just a few clicks away. Secure your appointment today and give yourself the care you deserve.
            </p>
            <Link href="/book">
              <Button size="lg" variant="outline" className="rounded-full px-8 py-6 text-lg border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300">
                View Appointments
              </Button>
            </Link>
      </section>
      </FadeIn>
      </div>
      </section>
      <ServicesSection />
      <SocialLinks />
      <FloatingContactBar />
    </div>
  );
}
