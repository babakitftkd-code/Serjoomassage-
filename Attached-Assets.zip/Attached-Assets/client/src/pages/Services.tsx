import { FadeIn } from "@/components/FadeIn";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const services = [
  {
    id: "relaxation",
    name: "Relaxation Massage",
    price: "$85 / 60 min",
    description: "A gentle, flowing massage designed to deeply relax the body, improve circulation, and calm the mind. Perfect for stress relief and overall well-being.",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80" // relaxing back massage spa
  },
  {
    id: "deep-tissue",
    name: "Deep Tissue Massage",
    price: "$105 / 60 min",
    description: "Targets the deeper layers of muscle and connective tissue. Ideal for chronic aches and pains, stiff neck, upper back, lower back pain, and tight muscles.",
    image: "https://images.unsplash.com/photo-1519824145371-296894a0daa9?w=800&q=80" // deep tissue physical therapy
  },
  {
    id: "back-pain",
    name: "Back Pain Therapy",
    price: "$120 / 75 min",
    description: "A specialized therapeutic treatment focusing intensely on the lumbar and thoracic spine to alleviate chronic or acute back pain, improving mobility and posture.",
    image: "https://images.unsplash.com/photo-1552693673-1bf958298935?w=800&q=80" // hot stone massage therapy back
  }
];

export default function Services() {
  return (
    <div className="min-h-screen bg-background pt-12 pb-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <FadeIn className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-medium mb-6">Our Services</h1>
          <p className="text-lg text-muted-foreground">
            We offer a curated selection of treatments designed to heal, restore, and rejuvenate.
          </p>
        </FadeIn>

        <div className="space-y-16 lg:space-y-24">
          {services.map((service, index) => (
            <FadeIn 
              key={service.id} 
              direction={index % 2 === 0 ? "left" : "right"}
              className="flex flex-col md:flex-row gap-8 lg:gap-16 items-center bg-card rounded-3xl p-6 lg:p-8 shadow-sm hover:shadow-md transition-shadow border border-border/30"
            >
              <div className={`w-full md:w-1/2 aspect-video rounded-2xl overflow-hidden ${index % 2 !== 0 ? 'md:order-2' : ''}`}>
                <img 
                  src={service.image} 
                  alt={service.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className={`w-full md:w-1/2 flex flex-col justify-center ${index % 2 !== 0 ? 'md:order-1' : ''}`}>
                <div className="flex flex-wrap items-baseline gap-4 mb-4">
                  <h2 className="text-3xl font-display font-medium">{service.name}</h2>
                  <span className="text-primary font-medium">{service.price}</span>
                </div>
                <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                  {service.description}
                </p>
                <div>
                  <Link href={`/book?service=${encodeURIComponent(service.name)}`}>
                    <Button className="rounded-full px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-md transition-all hover:-translate-y-0.5">
                      Book This Treatment
                    </Button>
                  </Link>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </div>
  );
}
