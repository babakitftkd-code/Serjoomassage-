import { FadeIn } from "@/components/FadeIn";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-[calc(100vh-80px)] bg-background py-16 md:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        <FadeIn className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-medium mb-6">
            Get In Touch
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Have a question or need to adjust your booking? Reach out to us, and
            we'll be happy to assist you.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
          <FadeIn direction="left" delay={0.2}>
            <div className="bg-card rounded-3xl p-8 lg:p-12 shadow-sm border border-border/30 h-full flex flex-col justify-center">
              <h2 className="text-2xl font-display font-medium mb-8">
                Contact Information
              </h2>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="bg-secondary/50 p-3 rounded-full text-primary mt-1">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Our Location</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      123 spa 

                      <br />
                      Suite 
                      <br />
                      home
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-secondary/50 p-3 rounded-full text-primary mt-1">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Phone Number</h3>
                    <p className="text-muted-foreground">+1 (647-217-5076)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-secondary/50 p-3 rounded-full text-primary mt-1">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Email Address</h3>
                    <p className="text-muted-foreground">
                      sergoomassage@gmail.com


                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-secondary/50 p-3 rounded-full text-primary mt-1">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Business Hours</h3>
                    <ul className="text-muted-foreground space-y-1">
                      <li>Mon - Fri: 9:00 AM - 8:00 PM</li>
                      <li>Saturday: 10:00 AM - 6:00 PM</li>
                      <li>Sunday: Closed</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </FadeIn>

          <FadeIn
            direction="right"
            delay={0.4}
            className="h-full min-h-[400px]"
          >
            {/* landing page contact map placeholder earth tones */}
            <div className="w-full h-full rounded-3xl overflow-hidden shadow-sm border border-border/30 relative group">
              <img
                src="https://pixabay.com/get/g7d07a231aba519baf476375ce17497980428b83e1351cfb9dd511246b77126a517d46a4792fdc1a7c04d447a166a00c6_1280.jpg"
                alt="Spa exterior"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-primary/10 mix-blend-multiply"></div>
            </div>
          </FadeIn>
        </div>
      </div>
    </div>
  );
}
